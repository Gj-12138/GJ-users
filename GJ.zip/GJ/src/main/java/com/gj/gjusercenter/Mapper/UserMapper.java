package com.gj.gjusercenter.Mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.gj.gjusercenter.model.User;


public interface UserMapper extends BaseMapper<User> {

}